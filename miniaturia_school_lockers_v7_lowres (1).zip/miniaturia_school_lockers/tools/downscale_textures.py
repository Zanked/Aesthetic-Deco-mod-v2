"""Уменьшает блочные текстуры в FACTOR раз (по умолчанию 4: 256->64, 128->32). Запускать ПОСЛЕ gen_textures.py.
UV в моделях заданы в единицах 0..16, поэтому менять модели не нужно.
    python3 tools/downscale_textures.py [FACTOR]"""
import glob, os, sys
from PIL import Image
FACTOR = int(sys.argv[1]) if len(sys.argv) > 1 else 4
T = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                 "src/main/resources/assets/schoollockers/textures/block/")
for f in glob.glob(T + "*.png"):
    if f.endswith("locker_handle.png"):
        continue
    im = Image.open(f).convert("RGBA")
    im.resize((im.width // FACTOR, im.height // FACTOR), Image.LANCZOS).save(f, optimize=True)
