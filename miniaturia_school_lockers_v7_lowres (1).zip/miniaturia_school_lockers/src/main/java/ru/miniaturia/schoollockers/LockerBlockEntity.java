package ru.miniaturia.schoollockers;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.Containers;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.ContainerOpenersCounter;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

/**
 * Хранилище шкафчика: две независимые дверцы (0 — левая, 1 — правая), у каждой 27 ячеек и свой замок.
 * Живёт в нижней половине.
 */
public class LockerBlockEntity extends BlockEntity {
    private final DoorContainer[] doors = { new DoorContainer(this, 0), new DoorContainer(this, 1) };
    /** Номер замка дверцы; 0 — не заперта. */
    private final long[] locks = new long[2];
    private final ContainerOpenersCounter[] counters = { createCounter(0), createCounter(1) };

    public LockerBlockEntity(BlockPos pos, BlockState state) {
        super(SchoolLockers.LOCKER_BE.get(), pos, state);
    }

    private ContainerOpenersCounter createCounter(int door) {
        return new ContainerOpenersCounter() {
            @Override
            protected void onOpen(Level level, BlockPos pos, BlockState state) {
                setDoorOpen(door, true);
                level.playSound(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                        SoundEvents.IRON_DOOR_OPEN, SoundSource.BLOCKS, 0.5F, level.random.nextFloat() * 0.1F + 0.9F);
            }

            @Override
            protected void onClose(Level level, BlockPos pos, BlockState state) {
                setDoorOpen(door, false);
                level.playSound(null, pos.getX() + 0.5, pos.getY() + 0.5, pos.getZ() + 0.5,
                        SoundEvents.IRON_DOOR_CLOSE, SoundSource.BLOCKS, 0.5F, level.random.nextFloat() * 0.1F + 0.9F);
            }

            @Override
            protected void openerCountChanged(Level level, BlockPos pos, BlockState state, int oldCount, int newCount) {
            }

            @Override
            protected boolean isOwnContainer(Player player) {
                return player.containerMenu instanceof ChestMenu menu && menu.getContainer() == doors[door];
            }
        };
    }

    // ---------- открывание ----------

    /** Игрок кликнул по дверце пустой рукой / не ключом. */
    public void openDoor(int door, Player player) {
        if (level == null) {
            return;
        }
        if (locks[door] != 0L) {
            level.playSound(null, getBlockPos(), SoundEvents.CHEST_LOCKED, SoundSource.BLOCKS, 1.0F, 1.0F);
            player.displayClientMessage(Component.translatable("message.schoollockers.locked"), true);
            return;
        }
        DoorContainer container = doors[door];
        player.openMenu(new SimpleMenuProvider(
                (id, inventory, p) -> ChestMenu.threeRows(id, inventory, container),
                Component.translatable("container.schoollockers.locker")));
    }

    /** Игрок кликнул по дверце ключом. */
    public void useKey(int door, ItemStack key, Player player) {
        if (level == null) {
            return;
        }
        long keyId = LockerKeyItem.getKeyId(key);
        long lock = locks[door];
        if (lock == 0L) {
            if (keyId == 0L) {
                keyId = level.random.nextLong();
                if (keyId == 0L) {
                    keyId = 1L;
                }
                LockerKeyItem.setKeyId(key, keyId);
            }
            locks[door] = keyId;
            setChanged();
            level.playSound(null, getBlockPos(), SoundEvents.IRON_TRAPDOOR_CLOSE, SoundSource.BLOCKS, 0.8F, 1.2F);
            player.displayClientMessage(Component.translatable("message.schoollockers.lock_on"), true);
        } else if (lock == keyId) {
            locks[door] = 0L;
            setChanged();
            level.playSound(null, getBlockPos(), SoundEvents.IRON_TRAPDOOR_OPEN, SoundSource.BLOCKS, 0.8F, 1.2F);
            player.displayClientMessage(Component.translatable("message.schoollockers.lock_off"), true);
        } else {
            level.playSound(null, getBlockPos(), SoundEvents.CHEST_LOCKED, SoundSource.BLOCKS, 1.0F, 1.0F);
            player.displayClientMessage(Component.translatable("message.schoollockers.wrong_key"), true);
        }
    }

    void doorOpened(int door, Player player) {
        if (!isRemoved() && !player.isSpectator() && level != null) {
            counters[door].incrementOpeners(player, level, getBlockPos(), getBlockState());
        }
    }

    void doorClosed(int door, Player player) {
        if (!isRemoved() && !player.isSpectator() && level != null) {
            counters[door].decrementOpeners(player, level, getBlockPos(), getBlockState());
        }
    }

    public void recheckOpen() {
        if (!isRemoved() && level != null) {
            for (ContainerOpenersCounter counter : counters) {
                counter.recheckOpeners(level, getBlockPos(), getBlockState());
            }
        }
    }

    /** Открывает/закрывает визуально одну дверцу (нижняя и верхняя половины). */
    private void setDoorOpen(int door, boolean open) {
        if (level == null) {
            return;
        }
        BooleanProperty prop = door == 0 ? LockerBlock.OPEN_LEFT : LockerBlock.OPEN_RIGHT;
        BlockPos pos = getBlockPos();
        BlockState state = level.getBlockState(pos);
        if (state.getBlock() instanceof LockerBlock) {
            level.setBlock(pos, state.setValue(prop, open), 3);
        }
        BlockPos up = pos.above();
        BlockState upState = level.getBlockState(up);
        if (upState.getBlock() instanceof LockerBlock) {
            level.setBlock(up, upState.setValue(prop, open), 3);
        }
    }

    /** Выбрасывает содержимое обеих дверец (при поломке). */
    public void dropAll(Level level, BlockPos pos) {
        for (DoorContainer door : doors) {
            Containers.dropContents(level, pos, door);
        }
    }

    // ---------- сохранение ----------

    @Override
    protected void saveAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.saveAdditional(tag, registries);
        for (int i = 0; i < 2; i++) {
            CompoundTag doorTag = new CompoundTag();
            ContainerHelper.saveAllItems(doorTag, doors[i].getItems(), registries);
            tag.put("Door" + i, doorTag);
            if (locks[i] != 0L) {
                tag.putLong("Lock" + i, locks[i]);
            }
        }
    }

    @Override
    protected void loadAdditional(CompoundTag tag, HolderLookup.Provider registries) {
        super.loadAdditional(tag, registries);
        for (int i = 0; i < 2; i++) {
            doors[i].getItems().clear();
            if (tag.contains("Door" + i)) {
                ContainerHelper.loadAllItems(tag.getCompound("Door" + i), doors[i].getItems(), registries);
            }
            locks[i] = tag.getLong("Lock" + i);
        }
        // миграция со старого формата (одно хранилище) в левую дверцу
        if (!tag.contains("Door0") && tag.contains("Items")) {
            ContainerHelper.loadAllItems(tag, doors[0].getItems(), registries);
        }
    }
}
