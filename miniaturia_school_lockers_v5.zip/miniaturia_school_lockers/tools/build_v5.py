"""v5: две двери 8x26 на блок (без зазоров). Генерирует текстуры, модели, блокстейты, lang.
Исходные текстуры берутся из tools/originals (вырезаны из reference.png).
Запуск: python3 tools/build_v5.py   (Pillow + numpy)"""
import os, json, glob
import numpy as np
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
A = f"{ROOT}/src/main/resources/assets/schoollockers"
TEX, MOD, ORIG = f"{A}/textures/block", f"{A}/models/block", f"{ROOT}/tools/originals"
COLORS = ['white','light_gray','gray','dark_gray','black','blue','light_blue','green','yellow','orange',
          'red','pink','purple','teal','brown','pastel_pink','pastel_blue','pastel_green']
LOWER, UPPER = 16, 10      # высота нижнего и верхнего блока (двери 8x26)
DW, DH = 16, 52            # дверь в пикселях (8x26 ед. по 2 px)

# ---------- текстуры ----------
# ВАЖНО: все текстуры строго 32x32 (квадрат). Не квадратные (например 8x32) Minecraft считает анимацией!
def save32(img, path):
    a = np.array(img.convert("RGBA"))
    h, w = a.shape[:2]
    a = np.pad(a, ((0, 32 - h), (0, 32 - w), (0, 0)), mode="edge")  # край продлеваем, чтобы не было тёмной каймы
    Image.fromarray(a, "RGBA").save(path)

def load(name, w, h):
    return Image.open(f"{ORIG}/{name}").convert("RGBA").crop((0, 0, w, h))

def stack(top, bot):
    im = Image.new("RGBA", (top.width, top.height + bot.height)); im.paste(top, (0, 0)); im.paste(bot, (0, top.height)); return im

for f in glob.glob(f"{TEX}/locker_*_fill_*.png"): os.remove(f)
for c in COLORS:
    door = stack(load(f"locker_{c}_front_top.png", 20, 32), load(f"locker_{c}_front_bottom.png", 20, 32)).resize((DW, DH), Image.LANCZOS)
    side = stack(load(f"locker_{c}_side_top.png", 16, 32), load(f"locker_{c}_side_bottom.png", 16, 32)).resize((DW, DH), Image.LANCZOS)
    roof = load(f"locker_{c}_roof.png", 20, 16).resize((16, 16), Image.LANCZOS)
    save32(door.crop((0, 0, DW, UPPER * 2)), f"{TEX}/locker_{c}_front_top.png")
    save32(door.crop((0, UPPER * 2, DW, DH)), f"{TEX}/locker_{c}_front_bottom.png")
    save32(side.crop((0, 0, DW, UPPER * 2)), f"{TEX}/locker_{c}_side_top.png")
    save32(side.crop((0, UPPER * 2, DW, DH)), f"{TEX}/locker_{c}_side_bottom.png")
    save32(roof, f"{TEX}/locker_{c}_roof.png")

# ---------- модели ----------
def box(a, b, faces): return {"from": a, "to": b, "faces": faces}
def F(uv, tex): return {"uv": uv, "texture": tex}

def closed(side, h, top, front="#front", sd="#side", roof="#roof", dy=0):
    L = side == "left"
    x1, x2 = (8, 16) if L else (0, 8)
    faces = {"north": F([0, 0, 8, h], front), "south": F([0, 0, 8, h], sd)}
    faces["east" if L else "west"] = F([8, 0, 0, h] if L else [0, 0, 8, h], sd)
    if top: faces["up"] = F([0, 0, 8, 8], roof)
    return [box([x1, dy, 6], [x2, dy + h, 14], faces)]

def opened(side, h, top):
    L = side == "left"
    xa, xb = (8, 16) if L else (0, 8)
    els = []
    # задняя стенка
    bw = {"north": F([0, 0, 8, h], "#inside"), "south": F([0, 0, 8, h], "#side")}
    if top: bw["up"] = F([0, 7, 8, 8], "#roof")
    els.append(box([xa, 0, 13], [xb, h, 14], bw))
    # внешняя стенка (у петли)
    ow = {"north": F([0, 0, 1, h], "#side")}
    if L: ow["east"] = F([7, 0, 0, h], "#side"); ow["west"] = F([0, 0, 7, h], "#inside"); ru = [7, 0, 8, 7]
    else: ow["west"] = F([0, 0, 7, h], "#side"); ow["east"] = F([7, 0, 0, h], "#inside"); ru = [0, 0, 1, 7]
    if top: ow["up"] = F(ru, "#roof")
    els.append(box([15, 0, 6] if L else [0, 0, 6], [16, h, 13] if L else [1, h, 13], ow))
    # внутренняя стенка (у соседней двери)
    iw = {"north": F([0, 0, 1, h], "#side")}
    if L: iw["east"] = F([7, 0, 0, h], "#inside"); ru = [0, 0, 1, 7]
    else: iw["west"] = F([0, 0, 7, h], "#inside"); ru = [7, 0, 8, 7]
    if top: iw["up"] = F(ru, "#roof")
    els.append(box([8, 0, 6] if L else [7, 0, 6], [9, h, 13] if L else [8, h, 13], iw))
    # пол (нижний блок) / потолок (верхний блок)
    fx1, fx2 = (9, 15) if L else (1, 7)
    if not top:
        els.append(box([fx1, 0, 6], [fx2, 1, 13], {"up": F([0, 0, 6, 7], "#inside"), "north": F([0, 0, 6, 1], "#side")}))
    else:
        els.append(box([fx1, h - 1, 6], [fx2, h, 13], {"down": F([0, 0, 6, 7], "#inside"), "up": F([1, 0, 7, 7], "#roof"), "north": F([0, 0, 6, 1], "#side")}))
    # распахнутая дверца (петля у внешнего края)
    if L:
        pf = {"east": F([0, 0, 8, h], "#front"), "west": F([0, 0, 8, h], "#inside"), "north": F([0, 0, 1, h], "#side")}
        if top: pf["up"] = F([7, 0, 8, 8], "#roof")
        els.append(box([15, 0, -2], [16, h, 6], pf))
    else:
        pf = {"west": F([0, 0, 8, h], "#front"), "east": F([8, 0, 0, h], "#inside"), "north": F([0, 0, 1, h], "#side")}
        if top: pf["up"] = F([0, 0, 1, 8], "#roof")
        els.append(box([0, 0, -2], [1, h, 6], pf))
    return els

def wj(path, obj):
    with open(path, "w", encoding="utf-8") as f: json.dump(obj, f, indent=2, ensure_ascii=False)

for f in glob.glob(f"{MOD}/locker_*.json"): os.remove(f)
# шаблоны (без текстур)
for side in ("left", "right"):
    for half, h, top in (("bottom", LOWER, False), ("top", UPPER, True)):
        wj(f"{MOD}/locker_door_{side}_{half}_closed.json", {"elements": closed(side, h, top)})
        wj(f"{MOD}/locker_door_{side}_{half}_open.json", {"elements": opened(side, h, top)})

ROT = {"north": 0, "east": 90, "south": 180, "west": 270}
ITEM_DISPLAY = {
    "gui": {"rotation": [30, 225, 0], "translation": [0, -2.1, 0], "scale": [0.42, 0.42, 0.42]},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 3, 0], "scale": [0.3, 0.3, 0.3]},
    "fixed": {"rotation": [0, 180, 0], "translation": [0, -2.2, 0], "scale": [0.43, 0.43, 0.43]},
    "thirdperson_righthand": {"rotation": [75, 45, 0], "translation": [0, 0, 0], "scale": [0.36, 0.36, 0.36]},
    "firstperson_righthand": {"rotation": [0, 45, 0], "translation": [0, -1.8, 0], "scale": [0.4, 0.4, 0.4]}}

for c in COLORS:
    T = lambda n: f"schoollockers:block/locker_{c}_{n}"
    for side in ("left", "right"):
        for half in ("bottom", "top"):
            for st in ("closed", "open"):
                wj(f"{MOD}/locker_{c}_door_{side}_{half}_{st}.json", {
                    "parent": f"schoollockers:block/locker_door_{side}_{half}_{st}",
                    "textures": {"front": T(f"front_{half}"), "side": T(f"side_{half}"), "roof": T("roof"),
                                 "inside": "schoollockers:block/locker_inside", "particle": T(f"side_{half}")}})
    parts = []
    for facing, y in ROT.items():
        for half, hn in (("lower", "bottom"), ("upper", "top")):
            for side, prop in (("left", "open_left"), ("right", "open_right")):
                for st, val in (("closed", "false"), ("open", "true")):
                    ap = {"model": f"schoollockers:block/locker_{c}_door_{side}_{hn}_{st}"}
                    if y: ap["y"] = y
                    parts.append({"when": {"facing": facing, "half": half, prop: val}, "apply": ap})
    wj(f"{A}/blockstates/locker_{c}.json", {"multipart": parts})
    els = []
    for side in ("left", "right"):
        els += closed(side, LOWER, False, "#fb", "#sb", "#roof", 0)
        els += closed(side, UPPER, True, "#ft", "#st", "#roof", LOWER)
    wj(f"{A}/models/item/locker_{c}.json", {
        "textures": {"fb": T("front_bottom"), "ft": T("front_top"), "sb": T("side_bottom"), "st": T("side_top"),
                     "roof": T("roof"), "particle": T("side_top")},
        "elements": els, "display": ITEM_DISPLAY})

# ---------- ключ ----------
os.makedirs(f"{A}/textures/item", exist_ok=True)
P = {'.': (0, 0, 0, 0), 'g': (236, 196, 64, 255), 'd': (170, 122, 28, 255), 'l': (255, 232, 140, 255), 'k': (96, 66, 14, 255)}
ART = [
 "................",
 "................",
 "....lllll.......",
 "...lggggdd......",
 "..lggkkkgdd.....",
 "..lgk...kgd.....",
 "..lgk...kgd.....",
 "..lggkkkgdd.....",
 "...lggggdd......",
 "....ldgdd.......",
 ".....lgd........",
 ".....lgd........",
 ".....lgdgg......",
 ".....lgd........",
 ".....lgdgg......",
 ".....ddd........"]
key = Image.new("RGBA", (16, 16))
for y, row in enumerate(ART):
    for x, ch in enumerate(row): key.putpixel((x, y), P[ch])
key.save(f"{A}/textures/item/locker_key.png")
wj(f"{A}/models/item/locker_key.json", {"parent": "minecraft:item/generated", "textures": {"layer0": "schoollockers:item/locker_key"}})

# ---------- lang ----------
for code, extra in (("ru_ru", {
        "item.schoollockers.locker_key": "Ключ от шкафчика",
        "message.schoollockers.locked": "Шкафчик заперт",
        "message.schoollockers.lock_on": "Шкафчик заперт на ключ",
        "message.schoollockers.lock_off": "Шкафчик отперт",
        "message.schoollockers.wrong_key": "Этот ключ не подходит",
        "tooltip.schoollockers.key_bound": "Ключ №%s",
        "tooltip.schoollockers.key_blank": "Пустой: привяжется при первом запирании",
        "tooltip.schoollockers.key_hint": "ПКМ по дверце — запереть/отпереть"}),
        ("en_us", {
        "item.schoollockers.locker_key": "Locker Key",
        "message.schoollockers.locked": "The locker is locked",
        "message.schoollockers.lock_on": "Locker locked",
        "message.schoollockers.lock_off": "Locker unlocked",
        "message.schoollockers.wrong_key": "This key doesn't fit",
        "tooltip.schoollockers.key_bound": "Key #%s",
        "tooltip.schoollockers.key_blank": "Blank: binds on first lock",
        "tooltip.schoollockers.key_hint": "Right-click a door to lock/unlock"})):
    p = f"{A}/lang/{code}.json"
    d = json.load(open(p, encoding="utf-8")); d.update(extra)
    wj(p, d)

# ---------- рецепт ключа ----------
wj(f"{ROOT}/src/main/resources/data/schoollockers/recipe/locker_key.json", {
    "type": "minecraft:crafting_shapeless", "category": "misc",
    "ingredients": [{"item": "minecraft:iron_ingot"}, {"item": "minecraft:iron_nugget"}],
    "result": {"id": "schoollockers:locker_key", "count": 1}})
print("ok")
