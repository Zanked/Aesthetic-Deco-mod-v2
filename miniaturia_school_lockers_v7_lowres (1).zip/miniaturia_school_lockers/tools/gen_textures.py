"""HD-текстуры школьных шкафчиков (v6).

Разрешение: 16 px на 1/16 блока (дверь 8x32 ед. = 128x512 px). Картинка рисуется целиком,
потом режется на нижний (0..16) и верхний (16..32) блок и складывается в атлас 256x256:
    слева  x 0..127   — лицевая сторона двери,
    справа x 128..255 — боковая стенка (глубина 8 ед.).
Крыша — отдельная 128x128. Всё строго квадратное (иначе Minecraft считает текстуру анимацией).

Запуск:  python3 tools/gen_textures.py   (Pillow + numpy)
"""
import os
import numpy as np
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEX = f"{ROOT}/src/main/resources/assets/schoollockers/textures/block"

W, H = 128, 512          # дверь: 8 x 32 ед. по 16 px
SIDE_W = 128             # боковая стенка: глубина 8 ед.
HALF = H // 2            # 256 px = один блок (16 ед.)

COLORS = {
    #  имя            основной цвет
    "white":        (206, 202, 206),
    "light_gray":   (156, 157, 162),
    "gray":         (104, 104, 110),
    "dark_gray":    (64, 64, 70),
    "black":        (30, 30, 35),
    "blue":         (30, 94, 192),
    "light_blue":   (92, 152, 216),
    "green":        (40, 122, 52),
    "yellow":       (226, 172, 40),
    "orange":       (216, 112, 32),
    "red":          (192, 34, 48),
    "pink":         (222, 112, 162),
    "purple":       (122, 54, 172),
    "teal":         (30, 152, 142),
    "brown":        (104, 64, 42),
    "pastel_pink":  (234, 152, 172),
    "pastel_blue":  (132, 162, 212),
    "pastel_green": (132, 178, 122),
}

# Наклейки и записки (по референсу): (вид, x-центр, y-центр, масштаб, параметры)
DECO = {
    "white":        [("smiley", 90, 150, 3), ("note", 78, 380, 3)],
    "light_gray":   [("sun", 64, 150, 3), ("note", 88, 372, 2)],
    "gray":         [("note", 62, 150, 3, {"faint": True}), ("dot", 90, 372, 3)],
    "dark_gray":    [("star", 64, 150, 3), ("note", 80, 372, 3)],
    "black":        [("star", 64, 150, 3), ("mosaic", 90, 380, 3), ("scribble", 40, 400, 2)],
    "blue":         [("note", 64, 125, 3), ("mosaic", 64, 190, 3), ("note", 84, 380, 3, {"colored": True})],
    "light_blue":   [("note", 72, 128, 3), ("mosaic", 80, 372, 3)],
    "green":        [("qr", 64, 140, 3), ("mosaic", 84, 376, 3)],
    "yellow":       [("warn", 64, 150, 3), ("note", 86, 376, 3)],
    "orange":       [("note", 64, 138, 3), ("heart", 62, 396, 3)],
    "red":          [("star", 64, 150, 3), ("note", 82, 376, 3)],
    "pink":         [("butterfly", 64, 150, 3), ("note", 72, 376, 3)],
    "purple":       [("cat", 64, 150, 3, {"dark": True}), ("note", 82, 366, 3), ("mosaic", 98, 318, 2)],
    "teal":         [("poster", 64, 150, 3), ("poster", 64, 372, 3, {"alt": True})],
    "brown":        [("note", 64, 136, 3), ("sparkle", 56, 372, 3)],
    "pastel_pink":  [("cat", 64, 148, 3), ("note", 74, 376, 3)],
    "pastel_blue":  [("butterfly", 64, 150, 3), ("note", 84, 376, 3)],
    "pastel_green": [("butterfly", 64, 150, 3), ("note", 64, 376, 3, {"colored": True})],
}

CREAM = (240, 236, 220)
PAPER = (232, 214, 176)
PAPER_D = (178, 152, 108)


# ------------------------------------------------------------------ утилиты
def clamp(v):
    return max(0, min(255, int(round(v))))


def sh(c, f):
    return tuple(clamp(v * f) for v in c)


def mix(a, b, t):
    return tuple(clamp(x * (1 - t) + y * t) for x, y in zip(a, b))


def value_noise(h, w, cell, rng):
    gh, gw = h // cell + 3, w // cell + 3
    g = (rng.random((gh, gw)) * 255).astype(np.uint8)
    im = Image.fromarray(g).resize((gw * cell, gh * cell), Image.BICUBIC)
    return np.asarray(im, dtype=np.float32)[:h, :w] / 255.0


def fbm(h, w, rng):
    return 0.45 * value_noise(h, w, 40, rng) + 0.35 * value_noise(h, w, 14, rng) + 0.20 * value_noise(h, w, 5, rng)


def blocky(h, w, cell, rng):
    g = rng.random((h // cell + 1, w // cell + 1)).astype(np.float32)
    return np.kron(g, np.ones((cell, cell), dtype=np.float32))[:h, :w]


def streaks(h, w, rng):
    g = (rng.random((h // 48 + 3, w // 3 + 3)) * 255).astype(np.uint8)
    im = Image.fromarray(g).resize((w, h), Image.BICUBIC)
    return np.asarray(im, dtype=np.float32) / 255.0


def weather(img, rng, strength=1.0, bottom_dirt=True):
    """Матовость, пятна, блочная «пиксельная» рябь как на референсе, подтёки и грязь у низа."""
    a = np.asarray(img.convert("RGB"), dtype=np.float32)
    h, w = a.shape[:2]
    n = fbm(h, w, rng) - 0.5
    b = blocky(h, w, 4, rng) - 0.5
    b2 = blocky(h, w, 8, rng) - 0.5
    st = streaks(h, w, rng) - 0.5
    f = 1.0 + strength * (0.26 * n + 0.07 * b + 0.06 * b2 + 0.07 * st)
    a = a * f[..., None]
    a += (rng.random((h, w)) - 0.5)[..., None] * 7.0 * strength
    if bottom_dirt:
        yy = np.linspace(0, 1, h, dtype=np.float32)[:, None]
        dirt = np.clip((yy - 0.78) / 0.22, 0, 1) ** 1.6 * (0.55 + 0.9 * fbm(h, w, rng))
        a *= (1 - 0.30 * dirt)[..., None]
        a[..., 0] += 6 * dirt
        a[..., 1] += 2 * dirt
    return Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGB").convert("RGBA")


def scratches(img, rng, base, count, region=None):
    lay = Image.new("RGBA", img.size, (0, 0, 0, 0))
    d = ImageDraw.Draw(lay)
    w, h = img.size
    x0, y0, x1, y1 = region or (0, 0, w, h)
    for i in range(count):
        x = rng.integers(x0, x1)
        y = rng.integers(y0, y1)
        ang = rng.uniform(0, np.pi)
        ln = rng.integers(5, 28)
        ex, ey = x + np.cos(ang) * ln, y + np.sin(ang) * ln
        if i % 3 == 0:
            col = (*sh(base, 0.45), 120)
        else:
            col = (*mix(base, (255, 255, 255), 0.55), 135)
        d.line([x, y, ex, ey], fill=col, width=1)
    for i in range(count // 2):       # царапины-сколы по краю краски
        x = rng.integers(x0, x1)
        y = rng.integers(y0, y1)
        d.rectangle([x, y, x + rng.integers(1, 4), y + rng.integers(1, 3)],
                    fill=(*mix(base, (200, 200, 205), 0.55), 150))
    return Image.alpha_composite(img, lay)


def rivet(d, cx, cy, base, r=2):
    d.ellipse([cx - r, cy - r, cx + r, cy + r], fill=sh(base, 0.55))
    d.ellipse([cx - r, cy - r, cx + r - 1, cy + r - 1], fill=mix(base, (255, 255, 255), 0.45))
    d.point([cx - 1, cy - 1], fill=(255, 255, 255))


def frame(d, w, h, base, rim=10, bracket=16, plinth=0, top_bracket=True):
    """Рама с фаской, канавкой, угловыми уголками с заклёпками."""
    lt, dk = sh(base, 1.22), sh(base, 0.66)
    d.rectangle([0, 0, w - 1, h - 1], fill=sh(base, 1.08))
    d.rectangle([rim, rim, w - 1 - rim, h - 1 - rim], fill=base)
    # внешняя фаска рамы
    d.line([0, 0, w - 1, 0], fill=lt, width=2)
    d.line([0, 0, 0, h - 1], fill=lt, width=2)
    d.line([0, h - 1, w - 1, h - 1], fill=dk, width=2)
    d.line([w - 1, 0, w - 1, h - 1], fill=dk, width=2)
    # канавка вокруг двери
    d.rectangle([rim - 2, rim - 2, w - 1 - rim + 2, h - 1 - rim + 2], outline=sh(base, 0.48), width=2)
    d.line([rim, rim, w - 1 - rim, rim], fill=lt)
    d.line([rim, rim, rim, h - 1 - rim], fill=lt)
    d.line([rim, h - 1 - rim, w - 1 - rim, h - 1 - rim], fill=dk)
    d.line([w - 1 - rim, rim, w - 1 - rim, h - 1 - rim], fill=dk)
    # уголки
    corners = [(0, 0), (w - bracket, 0), (0, h - bracket), (w - bracket, h - bracket)]
    for i, (cx, cy) in enumerate(corners):
        if i < 2 and not top_bracket:
            continue
        d.rectangle([cx, cy, cx + bracket - 1, cy + bracket - 1], fill=sh(base, 1.16), outline=sh(base, 0.5))
        d.line([cx + 1, cy + 1, cx + bracket - 2, cy + 1], fill=sh(base, 1.45))
        d.line([cx + 1, cy + 1, cx + 1, cy + bracket - 2], fill=sh(base, 1.45))
        rivet(d, cx + bracket // 2, cy + bracket // 2, base, 2)
    if plinth:
        d.rectangle([0, h - plinth, w - 1, h - 1], fill=sh(base, 0.58))
        d.line([0, h - plinth, w - 1, h - plinth], fill=sh(base, 1.2), width=2)
        for cx in (0, w - 22):                      # ножки
            d.rectangle([cx, h - plinth, cx + 21, h - 1], fill=sh(base, 0.80), outline=sh(base, 0.45))
            d.line([cx + 1, h - plinth + 1, cx + 20, h - plinth + 1], fill=sh(base, 1.3))
        d.rectangle([22, h - 8, w - 23, h - 1], fill=sh(base, 0.32))


def vents(d, x0, x1, y0, n, base, slot=7, pitch=14):
    lt, dk = sh(base, 1.35), sh(base, 0.5)
    dark = sh(base, 0.16)
    top = y0 - 6
    bot = y0 + (n - 1) * pitch + slot + 6
    d.rectangle([x0 - 6, top, x1 + 6, bot], fill=sh(base, 1.05), outline=dk)
    d.line([x0 - 6, bot + 1, x1 + 6, bot + 1], fill=lt)
    for i in range(n):
        y = y0 + i * pitch
        d.rectangle([x0, y, x1, y + slot - 1], fill=dark)
        d.line([x0, y, x1, y], fill=sh(base, 0.07))
        d.line([x0, y + slot, x1, y + slot], fill=lt, width=2)   # светлое ребро жалюзи
        d.line([x0, y + slot + 2, x1, y + slot + 2], fill=sh(base, 0.8))


def handle(d, base):
    """Чёрная ручка + светлая панель замка с чёрной щелью (как на референсе). Всё ниже y=256 (нижний блок)."""
    metal = (112, 114, 122)
    # панель замка
    d.rectangle([20, 296, 57, 340], fill=metal, outline=(46, 46, 52))
    d.line([21, 297, 56, 297], fill=(170, 172, 182))
    d.line([21, 297, 21, 339], fill=(160, 162, 172))
    rivet(d, 26, 303, metal, 2)
    rivet(d, 51, 333, metal, 2)
    d.rectangle([32, 312, 45, 328], fill=(24, 24, 28), outline=(10, 10, 12))
    d.rectangle([36, 316, 41, 324], fill=(70, 70, 78))
    # ручка (рычаг)
    d.rectangle([22, 262, 54, 294], fill=(26, 26, 31), outline=(8, 8, 10))
    d.rectangle([24, 264, 36, 276], fill=(58, 58, 68))
    d.line([24, 264, 52, 264], fill=(92, 92, 104))
    d.line([24, 264, 24, 292], fill=(80, 80, 92))
    d.rectangle([28, 282, 48, 291], fill=(14, 14, 18))
    # тень под ручкой
    d.line([20, 342, 59, 342], fill=sh(base, 0.45))


# ------------------------------------------------------------------ наклейки (пиксель-арт)
def _bitmap(rows, pal):
    h, w = len(rows), len(rows[0])
    im = Image.new("RGBA", (w, h), (0, 0, 0, 0))
    for y, r in enumerate(rows):
        for x, ch in enumerate(r):
            if ch in pal:
                im.putpixel((x, y), (*pal[ch], 255))
    return im


def spr_note(rng, colored=False, faint=False):
    w, h = 9, 12
    paper = (226, 238, 245) if colored else PAPER
    border = (120, 150, 190) if colored else PAPER_D
    im = Image.new("RGBA", (w, h), (*paper, 255))
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, w - 1, h - 1], outline=(*border, 255))
    d.point([w // 2, 0], fill=(190, 60, 60, 255))
    y = 3
    while y < h - 1:
        ln = int(rng.integers(3, w - 3))
        d.line([2, y, 2 + ln, y], fill=(*mix(border, (60, 50, 40), 0.35), 255))
        y += 2
    if colored:
        d.rectangle([2, 8, 6, 9], fill=(230, 160, 60, 255))
    if faint:
        a = np.asarray(im, dtype=np.float32)
        a[..., 3] *= 0.28
        im = Image.fromarray(a.astype(np.uint8), "RGBA")
    return im


def spr_mosaic(rng):
    pal = [(240, 200, 60), (60, 170, 225), (225, 70, 100), (95, 205, 115), (255, 255, 255), (150, 90, 210)]
    n = 8
    im = Image.new("RGBA", (n, n), (255, 255, 255, 255))
    for y in range(1, n - 1):
        for x in range(1, n - 1):
            im.putpixel((x, y), (*pal[int(rng.integers(0, len(pal)))], 255))
    return im


def spr_qr(rng):
    n = 9
    im = Image.new("RGBA", (n, n), (240, 244, 236, 255))
    d = ImageDraw.Draw(im)
    for y in range(1, n - 1):
        for x in range(1, n - 1):
            if rng.random() < 0.5:
                im.putpixel((x, y), (30, 60, 34, 255))
    for (cx, cy) in ((1, 1), (n - 4, 1), (1, n - 4)):
        d.rectangle([cx, cy, cx + 2, cy + 2], fill=(30, 60, 34, 255))
        im.putpixel((cx + 1, cy + 1), (240, 244, 236, 255))
    return im


def spr_poster(rng, alt=False):
    n_w, n_h = 9, 10
    im = Image.new("RGBA", (n_w, n_h), (226, 236, 214, 255))
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, n_w - 1, n_h - 1], outline=(150, 175, 140, 255))
    if not alt:
        d.line([4, 2, 4, 7], fill=(60, 130, 60, 255))
        d.rectangle([2, 2, 3, 3], fill=(90, 170, 80, 255))
        d.rectangle([5, 4, 6, 5], fill=(90, 170, 80, 255))
        d.rectangle([2, 7, 6, 8], fill=(150, 100, 60, 255))
    else:
        d.rectangle([2, 2, 6, 5], fill=(80, 170, 190, 255))
        d.line([2, 7, 6, 7], fill=(60, 130, 60, 255))
        d.point([4, 3], fill=(250, 220, 90, 255))
    return im


def _line_sprite(size, lines, col, dots=()):
    im = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    for ln in lines:
        d.line(ln, fill=(*col, 255))
    for p in dots:
        d.point(p, fill=(*col, 255))
    return im


def spr_star(col=CREAM):
    import math
    pts = []
    for i in range(5):
        a = -math.pi / 2 + i * 2 * math.pi / 5 * 2
        pts.append((6 + 5.5 * math.cos(a), 6.5 + 5.5 * math.sin(a)))
    lines = [(*pts[i], *pts[(i + 1) % 5]) for i in range(5)]
    return _line_sprite(13, lines, col, dots=[(1, 1), (11, 2)])


def spr_heart(col=(250, 240, 240)):
    rows = [".xx...xx.", "x..x.x..x", "x...x...x", "x.......x", ".x.....x.", "..x...x..", "...x.x...", "....x...."]
    return _bitmap(rows, {"x": col})


def spr_butterfly(col=CREAM):
    lines = [(1, 1, 9, 9), (9, 1, 1, 9), (5, 3, 5, 8)]
    return _line_sprite(11, lines, col, dots=[(0, 4), (10, 4), (4, 0), (6, 0)])


def spr_sun(col=CREAM):
    rows = ["..x.x.x..", ".x.....x.", "x..xxx..x", "..x...x..", "x.x...x.x", "..x...x..", "x..xxx..x", ".x.....x.", "..x.x.x.."]
    return _bitmap(rows, {"x": col})


def spr_sparkle(col=CREAM):
    rows = ["....x....", "....x....", "...x.x...", "xxx...xxx", "...x.x...", "....x....", "....x...."]
    return _bitmap(rows, {"x": col})


def spr_scribble(col=CREAM):
    rows = [".x....x.", "x.x..x.x", "..xxxx..", "x.x..x.x", ".x....x."]
    return _bitmap(rows, {"x": col})


def spr_dot(col=(200, 200, 205)):
    return _bitmap(["xx", "xx"], {"x": col})


def spr_smiley():
    rows = [
        "...kkkkk...",
        ".kkyyyyykk.",
        ".kyyyyyyyk.",
        "kyyyyyyyyyk",
        "kyykyyykyyk",
        "kyykyyykyyk",
        "kyyyyyyyyyk",
        "kykyyyyykyk",
        ".kyykkkyyk.",
        ".kkyyyyykk.",
        "...kkkkk...",
    ]
    return _bitmap(rows, {"k": (60, 44, 10), "y": (248, 206, 52)})


def spr_warn():
    rows = [
        ".......kk.......",
        "......kkkk......",
        "......kyyk......",
        ".....kkyykk.....",
        ".....kyykyk.....",
        "....kkyykykk....",
        "....kyyykyyk....",
        "...kkyyyyyykk...",
        "...kyyykkyyyk...",
        "..kkyyykkyyykk..",
        "..kyyyyyyyyyyk..",
        ".kkkkkkkkkkkkkk.",
    ]
    return _bitmap(rows, {"k": (34, 28, 14), "y": (232, 182, 48)})


def spr_cat(dark=False):
    rows = [
        ".pp......pp.",
        "pDDp....pDDp",
        "pDDDppppDDDp",
        "pDDDDDDDDDDp",
        "pDDDDDDDDDDp",
        "pDwDDDDDDwDp",
        "pDDDDDnnDDDp",
        "pDDDDDDDDDDp",
        ".pDDDDDDDDp.",
        "..pDDDDDDp..",
        "...pppppp...",
    ]
    if dark:
        pal = {"p": (244, 232, 236), "D": (74, 42, 100), "w": (246, 150, 200), "n": (246, 150, 200)}
    else:
        pal = {"p": (250, 244, 232), "D": (92, 52, 52), "w": (255, 214, 120), "n": (240, 140, 150)}
    return _bitmap(rows, pal)


def place(img, spr, cx, cy, s, shadow=True):
    sp = spr.resize((spr.width * s, spr.height * s), Image.NEAREST)
    x, y = int(cx - sp.width / 2), int(cy - sp.height / 2)
    if shadow:
        sh_im = Image.new("RGBA", sp.size, (0, 0, 0, 0))
        a = np.asarray(sp, dtype=np.uint8)[..., 3]
        arr = np.zeros((sp.height, sp.width, 4), dtype=np.uint8)
        arr[..., 3] = (a > 0) * 70
        sh_im = Image.fromarray(arr, "RGBA")
        img.alpha_composite(sh_im, (x + 2, y + 3))
    img.alpha_composite(sp, (x, y))
    # лёгкая «потёртость» наклейки
    return img


def decorate(img, name, rng):
    for item in DECO[name]:
        kind, cx, cy, s = item[:4]
        opt = item[4] if len(item) > 4 else {}
        if kind == "note":
            spr = spr_note(rng, opt.get("colored", False), opt.get("faint", False))
        elif kind == "mosaic":
            spr = spr_mosaic(rng)
        elif kind == "qr":
            spr = spr_qr(rng)
        elif kind == "poster":
            spr = spr_poster(rng, opt.get("alt", False))
        elif kind == "star":
            spr = spr_star()
        elif kind == "heart":
            spr = spr_heart()
        elif kind == "butterfly":
            spr = spr_butterfly()
        elif kind == "sun":
            spr = spr_sun()
        elif kind == "sparkle":
            spr = spr_sparkle()
        elif kind == "scribble":
            spr = spr_scribble()
        elif kind == "dot":
            spr = spr_dot()
        elif kind == "smiley":
            spr = spr_smiley()
        elif kind == "warn":
            spr = spr_warn()
        elif kind == "cat":
            spr = spr_cat(opt.get("dark", False))
        else:
            continue
        chalk = kind in ("star", "heart", "butterfly", "sun", "sparkle", "scribble")
        place(img, spr, cx, cy, s, shadow=not chalk)
    return img


# ------------------------------------------------------------------ текстуры
def make_front(name, base, rng):
    img = Image.new("RGB", (W, H), base)
    d = ImageDraw.Draw(img)
    frame(d, W, H, base, plinth=22)
    vents(d, 36, 91, 54, 4, base)          # верхние жалюзи (4 щели)
    vents(d, 36, 91, 426, 3, base)         # нижние жалюзи (3 щели)
    handle(d, base)
    img = weather(img, rng)
    img = decorate(img, name, rng)
    img = scratches(img, rng, base, 34)
    return img


def make_side(name, base, rng):
    img = Image.new("RGB", (SIDE_W, H), base)
    d = ImageDraw.Draw(img)
    frame(d, SIDE_W, H, base, plinth=22)
    # вертикальная «ступенька» панели + лёгкий второй шов
    d.line([SIDE_W // 2, 30, SIDE_W // 2, H - 40], fill=sh(base, 0.78))
    d.line([SIDE_W // 2 + 1, 30, SIDE_W // 2 + 1, H - 40], fill=sh(base, 1.12))
    img = weather(img, rng, 1.1)
    img = scratches(img, rng, base, 26)
    return img


def make_roof(name, base, rng):
    img = Image.new("RGB", (128, 128), base)
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, 127, 127], fill=sh(base, 1.12))
    d.rectangle([10, 10, 117, 117], fill=sh(base, 1.04), outline=sh(base, 0.55), width=2)
    d.line([12, 12, 115, 12], fill=sh(base, 1.35))
    d.line([12, 12, 12, 115], fill=sh(base, 1.35))
    for cx, cy in ((6, 6), (121, 6), (6, 121), (121, 121)):
        rivet(d, cx, cy, base, 2)
    img = weather(img, rng, 1.0, bottom_dirt=False)
    img = scratches(img, rng, base, 30)
    return img


def make_inside(rng):
    """Внутренность шкафчика. Верх и низ текстуры совпадают по яркости: два блока выглядят единой полостью."""
    base = (98, 102, 112)
    img = Image.new("RGB", (256, 256), base)
    a = np.asarray(img, dtype=np.float32)
    xx = np.linspace(0, 1, 256, dtype=np.float32)[None, :]
    edge = np.minimum(xx, 1 - xx) * 2                      # 0 у краёв, 1 в центре
    a *= (0.78 + 0.30 * np.clip(edge * 2.2, 0, 1))[..., None]
    n = fbm(256, 256, rng) - 0.5
    a *= (1 + 0.16 * n)[..., None]
    img = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8), "RGB").convert("RGBA")
    return scratches(img, rng, base, 34)


def make_handle():
    """Маленькая текстура 3D-ручки (чёрный металл с бликом)."""
    img = Image.new("RGBA", (32, 32), (26, 26, 31, 255))
    d = ImageDraw.Draw(img)
    d.rectangle([0, 0, 31, 31], outline=(10, 10, 12, 255), width=2)
    d.rectangle([4, 4, 20, 14], fill=(66, 66, 78, 255))
    d.line([3, 3, 28, 3], fill=(110, 110, 124, 255), width=2)
    return img


def seed_for(name):
    return abs(hash_str(name)) % (2 ** 32)


def hash_str(s):
    h = 2166136261
    for ch in s.encode():
        h = ((h ^ ch) * 16777619) & 0xFFFFFFFF
    return h


def save_atlas(front, side, name):
    for half, y0 in (("top", 0), ("bottom", HALF)):
        atlas = Image.new("RGBA", (256, 256), (0, 0, 0, 0))
        atlas.paste(front.crop((0, y0, W, y0 + HALF)), (0, 0))
        atlas.paste(side.crop((0, y0, SIDE_W, y0 + HALF)), (128, 0))
        atlas.save(f"{TEX}/locker_{name}_{half}.png", optimize=True)


def main():
    os.makedirs(TEX, exist_ok=True)
    for f in os.listdir(TEX):                      # убираем старые низкоразрешённые текстуры
        if f.startswith("locker_") and f.endswith(".png"):
            os.remove(os.path.join(TEX, f))
    for name, base in COLORS.items():
        rng = np.random.default_rng(seed_for(name))
        front = make_front(name, base, rng)
        side = make_side(name, base, rng)
        roof = make_roof(name, base, rng)
        save_atlas(front, side, name)
        roof.save(f"{TEX}/locker_{name}_roof.png", optimize=True)
        print("tex", name)
    make_inside(np.random.default_rng(7)).save(f"{TEX}/locker_inside.png", optimize=True)
    make_handle().save(f"{TEX}/locker_handle.png", optimize=True)


if __name__ == "__main__":
    main()
