"""Уменьшает блочные текстуры вдвое (256->128, 128->64). Запускать ПОСЛЕ gen_textures.py.
UV в моделях заданы в единицах 0..16, поэтому менять модели не нужно."""
import glob, os
from PIL import Image
T = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                 "src/main/resources/assets/schoollockers/textures/block/")
for f in glob.glob(T + "*.png"):
    if f.endswith("locker_handle.png"):
        continue
    im = Image.open(f).convert("RGBA")
    im.resize((im.width // 2, im.height // 2), Image.LANCZOS).save(f, optimize=True)
