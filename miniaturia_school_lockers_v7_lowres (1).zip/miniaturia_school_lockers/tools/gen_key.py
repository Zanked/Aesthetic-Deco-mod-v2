"""Гладкий ключ от шкафчика 64x64 (не пиксель-арт): рисуется в 1024x1024 с фаской/бликами и сжимается LANCZOS.
Запуск:  python3 tools/gen_key.py   (Pillow + numpy)"""
import os
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = f"{ROOT}/src/main/resources/assets/schoollockers/textures/item/locker_key.png"
N = 1024


def shape_mask():
    m = Image.new("L", (N, N), 0)
    d = ImageDraw.Draw(m)
    cx, cy = 790, 512
    d.ellipse([cx - 175, cy - 175, cx + 175, cy + 175], fill=255)       # головка (кольцо)
    d.rounded_rectangle([140, cy - 38, 640, cy + 38], radius=36, fill=255)   # стержень
    d.rounded_rectangle([585, cy - 62, 660, cy + 62], radius=26, fill=255)   # утолщение у головки
    d.rounded_rectangle([495, cy - 52, 545, cy + 52], radius=20, fill=255)   # второе кольцо
    d.rounded_rectangle([160, cy + 20, 262, cy + 170], radius=20, fill=255)  # зубец 1
    d.rounded_rectangle([300, cy + 20, 372, cy + 120], radius=18, fill=255)  # зубец 2
    d.rounded_rectangle([408, cy + 20, 470, cy + 150], radius=18, fill=255)  # зубец 3
    d.ellipse([cx - 82, cy - 82, cx + 82, cy + 82], fill=0)              # отверстие
    return m


def main():
    mask = shape_mask()
    m = np.asarray(mask, dtype=np.float32) / 255.0
    # карта высоты: размытая маска -> нормали -> освещение сверху-слева
    h = np.asarray(mask.filter(ImageFilter.GaussianBlur(16)), dtype=np.float32) / 255.0
    gy, gx = np.gradient(h)
    light = np.array([-0.55, -0.65, 0.52])
    nz = 0.020
    nrm = np.stack([-gx, -gy, np.full_like(gx, nz)], -1)
    nrm /= np.linalg.norm(nrm, axis=-1, keepdims=True)
    lam = np.clip((nrm * light).sum(-1), 0, 1)
    lam = (lam - lam.min()) / (lam.max() - lam.min() + 1e-6)
    dark, mid, bright = np.array([140, 92, 22]), np.array([232, 176, 52]), np.array([255, 240, 160])
    col = np.where(lam[..., None] < 0.55,
                   dark + (mid - dark) * (lam[..., None] / 0.55),
                   mid + (bright - mid) * ((lam[..., None] - 0.55) / 0.45))
    # зеркальный блик
    spec = np.clip((lam - 0.86) / 0.14, 0, 1) ** 2
    col = col + (np.array([255, 255, 255]) - col) * spec[..., None] * 0.8
    # тёмный контур
    edge = m - np.asarray(mask.filter(ImageFilter.MinFilter(21)), dtype=np.float32) / 255.0
    col = col * (1 - 0.75 * edge[..., None]) + np.array([70, 42, 8]) * (0.75 * edge[..., None])
    rgba = np.dstack([np.clip(col, 0, 255), m * 255]).astype(np.uint8)
    img = Image.fromarray(rgba, "RGBA").rotate(45, resample=Image.BICUBIC)
    # обрезаем по границам и вписываем в 64x64 с полями 2 px
    box = img.getbbox()
    img = img.crop(box)
    k = 60 / max(img.size)
    img = img.resize((max(1, round(img.width * k)), max(1, round(img.height * k))), Image.LANCZOS)
    out = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    out.alpha_composite(img, ((64 - img.width) // 2, (64 - img.height) // 2))
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    out.save(OUT, optimize=True)
    img = out
    return img


if __name__ == "__main__":
    main()
