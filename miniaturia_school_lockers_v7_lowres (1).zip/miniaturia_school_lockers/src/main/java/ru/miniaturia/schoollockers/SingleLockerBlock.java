package ru.miniaturia.schoollockers;

import javax.annotation.Nullable;

import com.mojang.serialization.MapCodec;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Одинарный школьный шкафчик: одна дверь 8x32 (2 блока в высоту), занимает половину ширины блока.
 * Какая половина (левая/правая для смотрящего) — выбирается по тому, куда игрок целится при установке:
 * так одинарные шкафчики можно ставить вплотную друг к другу и к двойным.
 */
public class SingleLockerBlock extends LockerBlock {
    public static final MapCodec<SingleLockerBlock> CODEC = simpleCodec(SingleLockerBlock::new);
    /** false — шкафчик в левой половине блока, true — в правой (с точки зрения смотрящего на лицевую сторону). */
    public static final BooleanProperty RIGHT = BooleanProperty.create("right");

    public SingleLockerBlock(Properties properties) {
        super(properties);
        registerDefaultState(defaultBlockState().setValue(RIGHT, false));
    }

    @Override
    protected MapCodec<? extends HorizontalDirectionalBlock> codec() {
        return CODEC;
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(RIGHT);
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        BlockState state = super.getStateForPlacement(ctx);
        if (state == null) {
            return null;
        }
        BlockPos pos = ctx.getClickedPos();
        Vec3 loc = ctx.getClickLocation();
        // 0 — левая половина (c >= 0.5), 1 — правая; тот же расчёт, что и при клике по дверце
        int index = doorIndexAt(state.getValue(FACING), pos, loc);
        return state.setValue(RIGHT, index == 1);
    }

    @Override
    protected VoxelShape shapeFor(BlockState state) {
        Direction facing = state.getValue(FACING);
        return state.getValue(RIGHT)
                ? rotatedBox(facing, 0, 6, 8, 14)
                : rotatedBox(facing, 8, 6, 16, 14);
    }

    @Override
    protected int doorIndex(BlockState state, BlockPos pos, Vec3 hit) {
        return state.getValue(RIGHT) ? 1 : 0;
    }
}
