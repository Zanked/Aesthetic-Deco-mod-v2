"""Вырезает шкафчики из reference.png, выпрямляет перспективу и делает текстуры + модели."""
import os, json, glob, sys
from PIL import Image, ImageEnhance
import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MODID = "schoollockers"
SRC = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(os.path.abspath(__file__)), "reference.png")
A = f"{ROOT}/src/main/resources/assets/{MODID}"
TEX = f"{A}/textures/block"
COLORS = ['white','light_gray','gray','dark_gray','black','blue','light_blue','green','yellow','orange',
          'red','pink','purple','teal','brown','pastel_pink','pastel_blue','pastel_green']
LEFTS = [30,115,201,287,370,457,544,630,715,800,885,972,1058,1144,1230,1307,1384,1457]
WIDTHS= [65,66,66,65,65,66,65,64,64,64,66,65,66,66,61,61,57,57]

im = Image.open(SRC).convert("RGB")
arr = np.array(im).astype(int)
bg = np.array([11,15,23])

for f in glob.glob(f"{TEX}/*"): os.remove(f)
os.makedirs(TEX, exist_ok=True)

K = 8  # апскейл перед варпом
def warp(big, quad, size):
    # quad: NW, SW, SE, NE (в координатах исходной картинки)
    q = []
    for (x, y) in quad: q += [x*K, y*K]
    return big.transform((size[0]*4, size[1]*4), Image.QUAD, q, Image.BICUBIC).resize(size, Image.LANCZOS)

def canvas(img, w=32, h=32):
    c = Image.new("RGBA", (w, h), (0,0,0,0)); c.paste(img.convert("RGBA"), (0,0)); return c

def enhance(img):
    img = ImageEnhance.Contrast(img).enhance(1.12)
    img = ImageEnhance.Color(img).enhance(1.12)
    return ImageEnhance.Sharpness(img).enhance(1.6)

for i, c in enumerate(COLORS):
    l = LEFTS[i]
    s = 1.0 if i in (3, 4) else min(1.0, WIDTHS[i]/65.0)
    sub = np.abs(arr[372:552, l-5:l+72] - bg).sum(axis=2) > 40
    ys = np.where(sub.sum(axis=1) > 3)[0]
    ymin, ymax = ys.min()+372, ys.max()+372
    X = lambda d: l + d*s            # d — смещение от левого края (для locker1)
    # передняя грань (4 угла), боковая, крыша
    fl, fr, br = X(2.0), X(42.5), X(63.5)
    tl_y, tr_y, bl_y, br_y = ymin+5, ymin+10, ymax-8, ymax-5
    back_y_top = ymin+3
    front = [(fl,tl_y),(fl,bl_y),(fr,br_y),(fr,tr_y)]
    side  = [(fr,tr_y),(fr,br_y),(br,ymax-8),(br,back_y_top)]
    roof  = [(fr,tr_y),(fl,tl_y),(X(23),ymin+1),(br,back_y_top)]   # зеркально: v=0 — передний край
    # NW,SW,SE,NE для крыши: NW=front-right, NE=front-left, SE=back-left, SW=back-right
    roof  = [(fr,tr_y),(br,back_y_top),(X(23),ymin+1),(fl,tl_y)]
    x0, y0 = l-10, ymin-10
    crop = im.crop((x0, y0, l+80, ymax+10))
    big = crop.resize((crop.width*K, crop.height*K), Image.LANCZOS)
    sh = lambda q: [(x-x0, y-y0) for x, y in q]
    f_img = enhance(warp(big, sh(front), (20, 64)))
    s_img = enhance(warp(big, sh(side), (16, 64)))
    r_img = enhance(warp(big, sh(roof), (20, 16)))
    canvas(f_img.crop((0,0,20,32))).save(f"{TEX}/locker_{c}_front_top.png")
    canvas(f_img.crop((0,32,20,64))).save(f"{TEX}/locker_{c}_front_bottom.png")
    canvas(s_img.crop((0,0,16,32))).save(f"{TEX}/locker_{c}_side_top.png")
    canvas(s_img.crop((0,32,16,64))).save(f"{TEX}/locker_{c}_side_bottom.png")
    canvas(r_img).save(f"{TEX}/locker_{c}_roof.png")

# ---- модели ----
def wj(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    json.dump(obj, open(path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)

def body(y0, y1, front, side, roof):
    return {"from":[3,y0,6],"to":[13,y1,14],"faces":{
        "north":{"uv":[0,0,10,16],"texture":front},
        "south":{"uv":[0,0,8,16],"texture":side},
        "west":{"uv":[0,0,8,16],"texture":side},
        "east":{"uv":[8,0,0,16],"texture":side},
        "up":{"uv":[0,0,10,8],"texture":roof},
        "down":{"uv":[0,0,10,8],"texture":roof}}}
DISPLAY = {
 "gui":{"rotation":[30,225,0],"translation":[0,-3.2,0],"scale":[0.4,0.4,0.4]},
 "ground":{"rotation":[0,0,0],"translation":[0,3,0],"scale":[0.25,0.25,0.25]},
 "fixed":{"rotation":[0,180,0],"translation":[0,-3,0],"scale":[0.35,0.35,0.35]},
 "thirdperson_righthand":{"rotation":[75,45,0],"translation":[0,0,0],"scale":[0.3,0.3,0.3]},
 "firstperson_righthand":{"rotation":[0,45,0],"translation":[0,-2,0],"scale":[0.35,0.35,0.35]}}
for c in COLORS:
    T = lambda n: f"{MODID}:block/locker_{c}_{n}"
    wj(f"{A}/models/block/locker_{c}_bottom.json",{"textures":{"front":T("front_bottom"),"side":T("side_bottom"),"roof":T("roof"),"particle":T("side_bottom")},
        "elements":[body(0,16,"#front","#side","#roof")]})
    wj(f"{A}/models/block/locker_{c}_top.json",{"textures":{"front":T("front_top"),"side":T("side_top"),"roof":T("roof"),"particle":T("side_top")},
        "elements":[body(0,16,"#front","#side","#roof")]})
    wj(f"{A}/models/item/locker_{c}.json",{"textures":{"fb":T("front_bottom"),"ft":T("front_top"),"sb":T("side_bottom"),"st":T("side_top"),"roof":T("roof"),"particle":T("side_top")},
        "elements":[body(0,16,"#fb","#sb","#roof"),body(16,32,"#ft","#st","#roof")],"display":DISPLAY})

# ---- превью ----
sheet = Image.new("RGBA", (18*(24+2), 70), (20,24,36,255))
for i, c in enumerate(COLORS):
    ft = Image.open(f"{TEX}/locker_{c}_front_top.png").crop((0,0,20,32)); fb = Image.open(f"{TEX}/locker_{c}_front_bottom.png").crop((0,0,20,32))
    sheet.paste(ft, (i*26+2, 2), ft); sheet.paste(fb, (i*26+2, 34), fb)
sheet.resize((sheet.width*3, sheet.height*3), Image.NEAREST).save("/home/claude/preview2.png")
